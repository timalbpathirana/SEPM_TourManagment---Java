package com.tourmanager;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

// Import for JDBC and MySQL
import java.sql.*;

public class Main {

	private static Scanner in = new Scanner(System.in);
	private static List<Staff> staffList = new ArrayList<>();
	private static List<Location> locationList = new ArrayList<>();
	private static List<TourType> tourTypeList = new ArrayList<>();
	private static List<Tour> tourList = new ArrayList<>();
	private static Staff currentUser = null;

	public static void main(String[] args) throws SQLException {

		// Loading dummy data
		dummyStaff();
		dummyLocations();
		dummyTourTypes();
		dummyTours();

		System.out.println("Welcome to Professional Computer Practise Tour Guide Program\n\n");

		do {
			System.out.println("******************* LOGIN **************************");
		} while (!login());

		int choice;

		do {
			System.out.println("*********************** MAIN MENU *****************************");
			System.out.println("Please select any option from the below List to proceed");
			System.out.println("1. Staff Management");
			System.out.println("2. Locations Management");
			System.out.println("3. Tours Management");
			System.out.println("4. Logout");
			System.out.println("5. Quit");
			System.out.print("Choose your option: ");
			choice = getInteger();

			int subchoice;
			switch (choice) {
			case 1:
				if (currentUser.getType() != 1) {
					showPermissionError();
				} else {
					do {
						subchoice = staffManagement();
					} while (subchoice != 4);
				}

				break;
			case 2:
				do {
					subchoice = locationManagement();
				} while (subchoice != 5);
				break;
			case 3:
				do {
					subchoice = tourManagement();
				} while (subchoice != 10);
				break;
			case 4:
				System.out.println("*************************** LOGOUT ******************************************");
				do {
					System.out.println("******************* LOGIN **************************");
				} while (!login());

				break;
			case 5:
				System.out.println("********************************* GOOD BYE *********************************");
				break;
			default:
			}
		} while (choice != 5);

	}

	private static int staffManagement() throws SQLException {

		System.out.println("*************************** STAFF MENU *********************************");
		System.out.println("1. Add Staff");
		System.out.println("2. Activate/Deactivate Staff");
		System.out.println("3. Show All Staff");

		// "Add Staff" method to Database (Hard coded for now)
		System.out.println("4. ADD STAFF TO THE DATABASE (HARD-CODED)");

		// "Add Staff" method to Database (Dynamic)
		System.out.println("5. ADD STAFF TO THE DATABASE (DYNAMIC)");

		// "Update Staff" method in Database (Using hard-coded data for now)
		System.out.println("6. UPDATE STAFF DETAILS IN THE DATABASE");

		// "Show all Staff" method from Database
		System.out.println("7. SHOW ALL THE STAFF ON THE DATABASE");

		// "Delete Staff" method in Database (Using hard-coded data for now)
		System.out.println("8. DELETE STAFF MEMBER FROM THE DATABASE");

		System.out.println("9. Back");

		System.out.print("Choose your option: ");
		int choice = getInteger();

		switch (choice) {
		case 1:
			addStaff();
			break;
		case 2:
			editStaff();
			break;
		case 3:
			if (currentUser.getType() != 1) {
				showPermissionError();
			} else {
				System.out.println("****************************** STAFF LIST **********************************");
				for (Staff staff : staffList) {
					System.out.println(staff);
				}
			}

			// "Add Staff" method to Database (Hard coded for now)
		case 4:
			insertStaffToDB();
			break;

		// "Add Staff" method to Database (Dynamic)
		case 5:
			insertDynamicStafftoDB();
			break;

		// "Update Staff" method in Database (Using hard-coded data for now)
		case 6:
			updateStaffInDB();
			break;

		// "Show all Staff" method from Database
		case 7:
			showAllStaffOnDB();
			break;

		// "Delete Staff" method in Database (Using hard-coded data for now)
		case 8:
			deleteStaffFromDB();
			break;

		case 9:
			break;
		default:
			System.out.println("Invalid Choice");

		}
		return choice;
	}

	// "Add Staff" method to Database (Hard coded for now)
	private static void insertStaffToDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "insert into users"
					+ " (id, firstName, lastName, type, username, password1, address, postCode)"
					+ " values ('1', 'John', 'Doe', '1', 'admin', 'admin', '123 ABC STREET MELBOURNE', '3000')";

			myStatement.executeUpdate(sql);

			System.out.println("STAFF INSERT FINISHED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Add Staff" method to Database (Dynamic)
	// Data is still added to the database successfully, however,
	// Exception in thread "main" java.util.NoSuchElementException: No line found
	private static void insertDynamicStafftoDB() throws SQLException {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		Connection myConn = null;
		PreparedStatement myStmt = null;

		Scanner scanner = null;

		try {

			scanner = new Scanner(System.in);

			System.out.print("Enter your ID: ");
			int id = getInteger();

			System.out.print("Enter your first name: ");
			String firstName = in.nextLine();

			System.out.print("Enter your last name: ");
			String lastName = in.nextLine();

			System.out.print("Enter your type: ");
			int type = getInteger();

			System.out.println("Enter your username: ");
			String username = in.nextLine();

			System.out.println("Enter your password: ");
			String password1 = in.nextLine();

			System.out.print("Enter your address: ");
			String address = in.nextLine();

			System.out.print("Enter your postcode: ");
			int postCode = getInteger();

			// 1. Connect to Database
			myConn = DriverManager.getConnection(url, user, password);

			// 2. Create Statement
			String sql = "insert into users "
					+ " (id, firstName, lastName, type, username, password1, address, postCode)"
					+ " values (?, ?, ?, ?, ?, ?, ?, ?)";

			myStmt = myConn.prepareStatement(sql);

			// Set Paramater Values
			myStmt.setInt(1, id);
			myStmt.setString(2, firstName);
			myStmt.setString(3, lastName);
			myStmt.setInt(4, type);
			myStmt.setString(5, username);
			myStmt.setString(6, password1);
			myStmt.setString(7, address);
			myStmt.setInt(8, postCode);

			// 3. Execute SQL Query
			myStmt.executeUpdate();

			System.out.println("STAFF INSERT COMPLETE.");
		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}

			if (myConn != null) {
				myConn.close();
			}

			if (scanner != null) {
				scanner.close();
			}
		}
	}

	// "Update Staff" method in Database (Using hard-coded data for now)
	private static void updateStaffInDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "update users " + " set firstName='Jack'" + " where id=1";

			myStatement.executeUpdate(sql);

			System.out.println("STAFF UPDATE FINISHED");

		}

		catch (Exception exception) {

			exception.printStackTrace();
		}

	}

	// "Delete Staff" method in Database (Using hard-coded data for now)
	private static void deleteStaffFromDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "delete from users where id='1'";

			int rowsAffected = myStatement.executeUpdate(sql);

			System.out.println("ROW(S) AFFECTED: " + rowsAffected);
			System.out.println("STAFF DELETED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	private static void addStaff() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** ADD NEW STAFF ********************************\n");
		System.out.print("Enter First Name: ");
		String firstName = in.nextLine();
		System.out.print("Enter Last Name: ");
		String lastName = in.nextLine();
		System.out.print("Enter Staff type (1: admin, 2: assistant): ");
		int type = getInteger();
		System.out.print("Enter username: ");
		String username = in.nextLine();
		System.out.print("Enter password: ");
		String password = in.nextLine();
		System.out.print("Enter address: ");
		String address = in.nextLine();

		System.out.print("Enter post code: ");
		int postCode = getInteger();
		Staff staff = new Staff(firstName, type, lastName, address, postCode, username, password);
		staffList.add(staff);
		System.out.println("\n******************** STAFF ADDED SUCCESSFULLY ********************************\n");
	}

	private static void editStaff() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** Edit STAFF ********************************\n");
		System.out.print("Enter ID of Staff to change status: ");
		int id = getInteger();

		Staff selected = null;
		for (Staff staff : staffList) {
			if (staff.getId() == id) {
				selected = staff;
			}
		}

		if (selected == null) {
			System.out.println("Staff with ID=" + id + " is not found");
			return;
		}

		int index = staffList.indexOf(selected);

		System.out.print("Enter new status (true, false): ");
		Boolean status = getBoolean();
		selected.setStatus(status);
		staffList.set(index, selected);
		System.out.println("\n******************** STAFF UPDATED SUCCESSFULLY ********************************\n");
	}

	private static int locationManagement() throws SQLException {
		System.out.println("*************************** LOCATION MENU *********************************");
		System.out.println("1. Add new Location");
		System.out.println("2. Edit Location");
		System.out.println("3. Remove Location");
		System.out.println("4. Show All Locations");

		// "Add New Location" method to Database (Hard coded for now)
		System.out.println("5. ADD NEW LOCATION TO THE DATABASE (HARD-CODED)");

		// "Add New Location" method to Database (Dynamic)
		System.out.println("6. ADD NEW LOCATION TO THE DATABASE (DYNAMIC)");

		// "Update Location" method in Database (Using hard-coded data for now)
		System.out.println("7. UPDATE LOCATION IN THE DATABASE");

		// "Show All Locations" method from Database
		System.out.println("8. SHOW ALL LOCATIONS FROM THE DATABASE");

		// "Delete Location" method in Database (Using hard-coded data for now)
		System.out.println("9. DELETE LOCATION FROM THE DATABASE");

		System.out.println("10. Back");
		System.out.print("Choose your option: ");
		int choice = getInteger();
		switch (choice) {
		case 1:
			addLocation();
			break;
		case 2:
			editLocation();
			break;
		case 3:
			removeLocation();
			break;
		case 4:
			for (Location location : locationList) {
				System.out.println(location);
			}

			// "Add New Location" method to Database (Hard coded for now)
		case 5:
			insertLocationToDB();
			break;

		// "Add New Location" method to Database (Dynamic)
		case 6:
			insertDynamicLocationtoDB();
			break;

		// "Update Location" method in Database (Using hard-coded data for now)
		case 7:
			updateLocationInDB();
			break;

		// "Show all Locations" method from Database
		case 8:
			showAllLocationsOnDB();
			break;

		// "Delete Location" method in Database (Using hard-coded data for now)
		case 9:
			deleteLocationInDB();
			break;

		case 10:
			break;
		default:
			System.out.println("Invalid Choice");

		}
		return choice;
	}

	// "Add New Location" method to Database (Hard coded for now)
	private static void insertLocationToDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "insert into location " + " (id, name, xCoordinate, yCoordinate, description, time)"
					+ " values ('1', 'Location Name', '10.00', '20.00', 'Location Description', '60.00')";

			myStatement.executeUpdate(sql);

			System.out.println("LOCATION INSERT FINISHED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Add New Location" method to Database (Dynamic)
	// Data is still added to the database successfully, however,
	// Exception in thread "main" java.util.NoSuchElementException: No line found
	private static void insertDynamicLocationtoDB() throws SQLException {
		
		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		Connection myConn = null;
		PreparedStatement myStmt = null;

		Scanner scanner = null;

		try {

			scanner = new Scanner(System.in);

			System.out.print("Enter the Location's ID: ");
			int id = getInteger();

			System.out.print("Enter the Location's name: ");
			String name = in.nextLine();

			System.out.print("Enter the Location's x-coordinate: ");
			double xCoordinate = getDouble();

			System.out.print("Enter the Location's y-coordinate: ");
			double yCoordinate = getDouble();

			System.out.println("Enter the Location's description: ");
			String description = in.nextLine();

			System.out.println("Enter the Location's minimum time: ");
			double time = getDouble();

			// 1. Connect to Database
			myConn = DriverManager.getConnection(url, user, password);

			// 2. Create Statement
			String sql = "insert into location "
					+ " (id, name, xCoordinate, yCoordinate, description, time)"
					+ " values (?, ?, ?, ?, ?, ?)";

			myStmt = myConn.prepareStatement(sql);

			// Set Paramater Values
			myStmt.setInt(1, id);
			myStmt.setString(2, name);
			myStmt.setDouble(3, xCoordinate);
			myStmt.setDouble(4, yCoordinate);
			myStmt.setString(5, description);
			myStmt.setDouble(6, time);
			
			// 3. Execute SQL Query
			myStmt.executeUpdate();

			System.out.println("STAFF INSERT COMPLETE.");
		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}

			if (myConn != null) {
				myConn.close();
			}

			if (scanner != null) {
				scanner.close();
			}
		}
		

	}

	// "Update Location" method in Database (Using hard-coded data for now)
	private static void updateLocationInDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "update location " + " set time='1000.00'" + " where id=1";

			myStatement.executeUpdate(sql);

			System.out.println("LOCATION UPDATE FINISHED");

		}

		catch (Exception exception) {

			exception.printStackTrace();
		}

	}

	// "Show all Locations" method from Database
	private static void showAllLocationsOnDB() {
		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney", "root", "52cY6^#q3%");

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			ResultSet myResultSet = myStatement.executeQuery("select * from location");

			// 4. Process result set
			while (myResultSet.next()) {

				System.out.println(myResultSet.getString("id") + ", " + myResultSet.getString("name") + ", "
						+ myResultSet.getString("xCoordinate") + ", " + myResultSet.getString("yCoordinate") + ", "
						+ myResultSet.getString("description") + ", " + myResultSet.getString("time"));

			}

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Delete Location" method in Database (Using hard-coded data for now)
	private static void deleteLocationInDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "delete from location where id='1'";

			int rowsAffected = myStatement.executeUpdate(sql);

			System.out.println("ROW(S) AFFECTED: " + rowsAffected);
			System.out.println("LOCATION DELETED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	private static void addLocation() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** ADD NEW LOCATION ********************************\n");
		System.out.print("Enter Location Name: ");
		String name = in.nextLine();
		System.out.print("Enter X coordinate: ");
		Double x = getDouble();
		System.out.print("Enter Y coordinate: ");
		Double y = getDouble();
		System.out.print("Enter Description: ");
		String desc = in.nextLine();
		System.out.print("Enter minimum time: ");
		Double time = getDouble();

		Location location = new Location(name, x, y, desc, time);
		locationList.add(location);
		System.out.println("\n******************** LOCATION ADDED SUCCESSFULLY ********************************\n");
	}

	private static void editLocation() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** EDIT LOCATION ********************************\n");

		Location selected = findLocationWithID();

		if (selected == null) {
			return;
		}

		System.out.print("Enter new Location Name(Empty to keep previous): ");
		String name = in.nextLine();
		if (name.isEmpty()) {
			name = selected.getName();
		}
		System.out.print("Enter X coordinate(Empty to keep previous): ");
		Double x;
		String data = in.nextLine();
		if (data.isEmpty()) {
			x = selected.getXco();
		} else {
			x = getDouble();
		}
		System.out.print("Enter Y coordinate(Empty to keep previous): ");
		Double y;
		data = in.nextLine();
		if (data.isEmpty()) {
			y = selected.getYCo();
		} else {
			y = getDouble();
		}
		System.out.print("Enter Description(Empty to keep previous): ");
		String desc = in.nextLine();
		if (desc.isEmpty()) {
			desc = selected.getDesc();
		}
		System.out.print("Enter minimum time(Empty to keep previous): ");
		Double time;
		data = in.nextLine();
		if (data.isEmpty()) {
			time = selected.getTime();
		} else {
			time = getDouble();
		}

		int index = locationList.indexOf(selected);
		selected.setDesc(desc);
		selected.setName(name);
		selected.setTime(time);
		selected.setXco(x);
		selected.setYCo(y);
		locationList.set(index, selected);
		System.out.println("\n******************** LOCATION UPDATED SUCCESSFULLY ********************************\n");
	}

	private static void removeLocation() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** REMOVE LOCATION ********************************\n");

		Location selected = findLocationWithID();

		if (selected == null) {
			return;
		}

		for (Tour tour : tourList) {
			for (Location location : tour.getLocations()) {
				if (location == selected) {
					System.out.println("********************** CANNOT DELETE LOCATION. IT IS USED BY TOUR="
							+ tour.getName() + "**************************");
				}
			}
		}

		locationList.remove(selected);

		System.out.println("************************* LOCATION REMOVED SUCCESSFULLY ****************************");
	}

	private static Location findLocationWithID() {
		System.out.print("Enter location ID: ");
		int id = getInteger();

		Location selected = null;
		for (Location location : locationList) {
			if (location.getId() == id) {
				selected = location;
			}
		}

		if (selected == null) {
			System.out.println("Location with ID=" + id + " is not found");
		}

		return selected;
	}

	private static int tourManagement() {
		System.out.println("*************************** TOUR MENU *********************************");
		System.out.println("1. Add Tour Type");
		System.out.println("2. Edit Tour Type");
		System.out.println("3. Remove Tour Type");
		System.out.println("4. Show All Tour Types");

		// "Add Tour Type" method to Database (Hard coded for now)
		System.out.println("5. ADD TOUR TYPE TO DATABASE");

		// "Update Tour Type" method in Database (Using hard-coded data for now)
		System.out.println("6. UPDATE TOUR TYPE IN DATABASE");

		// "Show all Tour Types" method from Database
		System.out.println("7. SHOW ALL TOUR TYPES IN DATABASE");

		// "Delete Tour Type" method in Database (Using hard-coded data for now)
		System.out.println("8. DELETE TOUR TYPE IN DATABASE");

		System.out.println("9. Add new Tour");
		System.out.println("10. Edit Tour");
		System.out.println("11. Remove Tour");
		System.out.println("12. Show All Tours");
		System.out.println("13. Select a tour");

		// "Add New Tour" method to Database (Hard coded for now)
		System.out.println("14. ADD NEW TOUR TO DATABASE");

		// "Update Tour" method in Database (Using hard-coded data for now)
		System.out.println("15. UPDATE TOUR IN DATABASE");

		// "Show all Tours" method from Database
		System.out.println("16. SHOW ALL TOURS IN DATABASE");

		// "Delete Tour method in Database (Using hard-coded data for now)
		System.out.println("17. DELETE TOUR IN DATABASE");

		System.out.println("18. Back");
		System.out.print("Choose your option: ");
		int choice = getInteger();
		switch (choice) {
		case 1:
			addTourType();
			break;
		case 2:
			editTourType();
			break;
		case 3:
			removeTourType();
			break;
		case 4:
			for (TourType tourType : tourTypeList) {
				System.out.println(tourType);
			}
			break;

		// "Add Tour Type" method to Database (Hard coded for now)
		case 5:
			addTourTypeToDB();
			break;

		// "Update Tour Type" method in Database (Using hard-coded data for now)
		case 6:
			updateTourTypeInDB();
			break;

		// "Show all Tour Types" method from Database
		case 7:
			showAllTourTypesInDB();
			break;

		// "Delete Tour Type" method in Database (Using hard-coded data for now)
		case 8:
			deleteTourTypeInDB();
			break;

		case 9:
			addTour();
			break;
		case 10:
			editTour();
			break;
		case 11:
			removeTour();
			break;
		case 12:
			System.out.println("***************************** TOUR LIST *****************************");
			for (Tour tour : tourList) {

				System.out.println(tour);
			}
			break;
		case 13:
			tourToVoice();
			break;

		// "Add New Tour" method to Database (Hard coded for now)
		case 14:
			addNewTourToDB();
			break;

		// "Update Tour" method in Database (Using hard-coded data for now)
		case 15:
			updateTourInDB();
			break;

		// "Show all Tours" method from Database
		case 16:
			showAllToursInDB();
			break;

		// "Delete Tour method in Database (Using hard-coded data for now)
		case 17:
			deleteTourInDB();
			break;

		case 18:
			break;
		default:
			System.out.println("Invalid Choice");

		}
		return choice;
	}

	// "Add Tour Type" method to Database (Hard coded for now)
	private static void addTourTypeToDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "insert into tourType " + " (id, name)" + " values ('1', 'Tour Type Name')";

			myStatement.executeUpdate(sql);

			System.out.println("TOUR TYPE INSERT FINISHED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Update Tour Type" method in Database (Using hard-coded data for now)
	private static void updateTourTypeInDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "update tourType " + " set name='CHANGE TOUR TYPE NAME'" + " where id=1";

			myStatement.executeUpdate(sql);

			System.out.println("TOUR TYPE UPDATE FINISHED");

		}

		catch (Exception exception) {

			exception.printStackTrace();
		}

	}

	// "Show all Tour Types" method from Database
	private static void showAllTourTypesInDB() {

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney", "root", "52cY6^#q3%");

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			ResultSet myResultSet = myStatement.executeQuery("select * from tourType");

			// 4. Process result set
			while (myResultSet.next()) {

				System.out.println(myResultSet.getString("id") + ", " + myResultSet.getString("name"));

			}

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Delete Tour Type" method in Database (Using hard-coded data for now)
	private static void deleteTourTypeInDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "delete from tourType where id='1'";

			int rowsAffected = myStatement.executeUpdate(sql);

			System.out.println("ROW(S) AFFECTED: " + rowsAffected);
			System.out.println("TOUR TYPE DELETED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Add New Tour" method to Database (Hard coded for now)
	private static void addNewTourToDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "insert into tour " + " (id, name, type, duration)"
					+ " values ('1', 'Tour Name', 'Tour Type', '50')";

			myStatement.executeUpdate(sql);

			System.out.println("TOUR TYPE INSERT FINISHED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Update Tour" method in Database (Using hard-coded data for now)
	private static void updateTourInDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "update tour " + " set name='CHANGE TOUR NAME'" + " where id=1";

			myStatement.executeUpdate(sql);

			System.out.println("TOUR UPDATE FINISHED");

		}

		catch (Exception exception) {

			exception.printStackTrace();
		}

	}

	// "Show all Tours" method from Database
	private static void showAllToursInDB() {

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney", "root", "52cY6^#q3%");

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			ResultSet myResultSet = myStatement.executeQuery("select * from tour");

			// 4. Process result set
			while (myResultSet.next()) {

				System.out.println(myResultSet.getString("id") + ", " + myResultSet.getString("name") + ", "
						+ myResultSet.getString("type") + ", " + myResultSet.getString("duration"));

			}

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	// "Delete Tour method in Database (Using hard-coded data for now)
	private static void deleteTourInDB() {

		String url = "jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney";
		String user = "root";
		String password = "52cY6^#q3%";

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(url, user, password);

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			String sql = "delete from tour where id='1'";

			int rowsAffected = myStatement.executeUpdate(sql);

			System.out.println("ROW(S) AFFECTED: " + rowsAffected);
			System.out.println("TOUR DELETED");

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

	private static void addTourType() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** ADD NEW TOUR TYPE ********************************\n");
		System.out.print("Enter Tour Type: ");
		String name = in.nextLine();
		TourType tourType = new TourType(name);
		tourTypeList.add(tourType);
		System.out.println("******************** TOUR TYPE SAVED SUCCESSFULLY ********************************\n");
	}

	private static void editTourType() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** Edit TOUR TYPE ********************************\n");
		TourType selected = findTourTypeWithID();

		if (selected == null) {
			return;
		}
		int index = tourTypeList.indexOf(selected);
		System.out.print("Enter Tour Type name: ");
		String name = in.nextLine();
		selected.setName(name);
		tourTypeList.set(index, selected);
		System.out.println("******************** TOUR TYPE UPDATED SUCCESSFULLY ********************************\n");
	}

	private static void removeTourType() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** REMOVE TOUR TYPE ********************************\n");

		TourType selected = findTourTypeWithID();

		if (selected == null) {
			return;
		}

		for (Tour tour : tourList) {
			if (tour.getType() == selected) {
				System.out.println("******************** CANNOT DELETE THIS TOUR TYPE. IT IS USED BY TOUR= "
						+ tour.getName() + " ********************************");
				return;
			}
		}
		tourTypeList.remove(selected);
		System.out.println("******************** TOUR TYPE REMOVED SUCCESSFULLY ********************************\n");
	}

	private static TourType findTourTypeWithID() {
		System.out.print("Enter Tour Type ID: ");
		int id = getInteger();

		TourType selected = null;
		for (TourType tourType : tourTypeList) {
			if (tourType.getId() == id) {
				selected = tourType;
			}
		}

		if (selected == null) {
			System.out.println("Tour Type with ID=" + id + " is not found");

		}
		return selected;
	}

	private static void addTour() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** ADD TOUR ********************************\n");
		System.out.print("Enter Tour Name: ");
		String name = in.nextLine();
		System.out.println("Select Tour Type: ");
		showTourTypes();
		System.out.print("Selected Type: ");
		int type = getInteger();
		while (type > tourTypeList.size()) {
			System.out.print("Invalid Tour type. select again: ");
			type = getInteger();
		}
		TourType selected = tourTypeList.get(type - 1);
		System.out.println("Select location ids");
		showLocations();
		System.out.print("Locations: ");
		List<Location> locations = getLocations();

		Tour tour = new Tour(name, selected);
		tour.setLocations(locations);

		tourList.add(tour);
	}

	private static void editTour() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** Edit TOUR ********************************\n");
		Tour selected = findTourWithID();

		if (selected == null) {
			return;
		}
		int index = tourList.indexOf(selected);
		System.out.print("Enter Tour name(Enter to keep old): ");
		String name = in.nextLine();
		if (name.isEmpty()) {
			name = selected.getName();
		}
		System.out.print("Select tour type: ");
		showTourTypes();
		int type = getInteger();
		while (type > tourTypeList.size()) {
			System.out.print("Invalid tour type id. Try again: ");
			type = getInteger();
		}
		TourType tourType = tourTypeList.get(type - 1);
		System.out.print("Select Locations: ");
		showLocations();
		List<Location> locations = getLocations();

		selected.setName(name);
		selected.setType(tourType);
		selected.setLocations(locations);
		tourList.set(index, selected);
	}

	private static void removeTour() {
		if (currentUser.getType() != 1) {
			showPermissionError();
			return;
		}
		System.out.println("******************** REMOVE TOUR ********************************\n");

		Tour selected = findTourWithID();

		if (selected == null) {
			return;
		}
		tourList.remove(selected);
		System.out.println("******************** TOUR REMOVED SUCCESSFULLY ********************************\n");
	}

	private static Tour findTourWithID() {
		System.out.print("Enter Tour ID: ");
		int id = getInteger();

		Tour selected = null;
		for (Tour tour : tourList) {
			if (tour.getId() == id) {
				selected = tour;
			}
		}

		if (selected == null) {
			System.out.println("Tour with ID=" + id + " is not found");
		}

		return selected;
	}

	private static boolean login() {

		System.out.print("Username: ");
		String username = in.nextLine();
		System.out.print("Password: ");
		String password = in.nextLine();
		for (Staff staff : staffList) {
			if (staff.getUsername().equals(username) && staff.getPassword().equals(password)) {
				System.out.println("Welcome " + staff.getFirstName());
				currentUser = staff;
				return true;
			}
		}
		System.out.println("Invalid username or password. Please try again\n");
		return false;
	}

	private static void dummyStaff() {
		Staff staff = new Staff("Administrator", 1, "Last Name 1", "Address 1", 123, "admin", "admin");
		Staff staff2 = new Staff("First Name 2", 2, "Last Name 2", "Address 2", 321, "user", "user");
		staffList.add(staff);
		staffList.add(staff2);
	}

	private static void dummyLocations() {
		Location location = new Location("Location Name ", 2.3, 2.5, "Address ", 2.0);
		Location location2 = new Location("Location Name2 ", 2.3, 2.5, "Address2 ", 2.0);
		locationList.add(location);
		locationList.add(location2);

	}

	private static void dummyTourTypes() {
		TourType tourtype = new TourType("Tour Type ");
		TourType tourtype2 = new TourType("Tour Type 2");
		tourTypeList.add(tourtype);
		tourTypeList.add(tourtype2);
	}

	private static void dummyTours() {
		Tour tour = new Tour("Tour 1", tourTypeList.get(0));
		Tour tour2 = new Tour("Tour 2", tourTypeList.get(1));
		tourList.add(tour);
		tourList.add(tour2);
		tour.setLocations(locationList);
	}

	private static void showTourTypes() {
		System.out.println("Available Types are: ");
		int sr = 1;
		for (TourType tourType : tourTypeList) {
			System.out.println(sr + " - " + tourType.getName());
			sr++;
		}
	}

	private static void showTours() {
		System.out.println("Available Tours are: ");
		int sr = 1;
		for (Tour tour : tourList) {
			System.out.println(sr + " - " + tour.getName());
			sr++;
		}
	}

	private static void showLocations() {
		System.out.println("Available locations are: ");
		for (int i = 1; i <= locationList.size(); i++) {
			System.out.println(i + " - " + locationList.get(i - 1).getName());
		}
	}

	private static Integer getInteger() {

		int num;
		do {
			try {
				num = Integer.parseInt(in.nextLine());
			} catch (NumberFormatException ex) {
				num = -1;
				System.out.print("Invalid number. Try again: ");
			}
		} while (num <= 0);
		return num;
	}

	private static Double getDouble() {

		double num;
		do {
			try {
				num = Double.parseDouble(in.nextLine());
			} catch (NumberFormatException ex) {
				num = -100;
				System.out.print("Invalid number. Try again: ");
			}
		} while (num <= 0);
		return num;
	}

	private static List<Location> getLocations() {
		List<Location> locations = new ArrayList<>();
		String[] ids = in.nextLine().split(" ");
		for (String id : ids) {
			try {
				int locID = Integer.parseInt(id);
				if (locID < 0 || locID > locationList.size()) {
					System.out.println("Location with id: " + locID + " is not found. Hence cannot be added");
				} else {
					locations.add(locationList.get(locID - 1));
				}
			} catch (NumberFormatException ex) {
				System.out.println("Invalid id=" + id);
			}
		}
		return locations;
	}

	private static Boolean getBoolean() {
		String data = in.next();
		Boolean value = Boolean.parseBoolean(data);
		in.nextLine();
		return value;
	}

	private static void tourToVoice() {
		System.out.println("Select a tour: ");
		showTours();
		System.out.print("Your choice: ");
		int id = getInteger();
		while (id > tourList.size()) {
			System.out.print("Invalid tour. Try again: ");
			id = getInteger();
		}
		Tour tour = tourList.get(id - 1);

		System.out.println("You have selected");
		System.out.println(tour);
		Voice voice = VoiceManager.getInstance().getVoice("kevin16");
		voice.allocate();
		voice.speak("Welcome to Professional Computer Practice Tour Guide");
		voice.speak("You have selected. " + tour.getName() + ", of tour type, " + tour.getType().getName());
		voice.speak("Minimum time required to complete the tour is. " + tour.getDuration() + " minutes.");
		voice.speak("This tour has Locations. ");
		int i = 1;
		if (tour.getLocations().size() > 0) {
			for (Location location : tour.getLocations()) {
				voice.speak("Location " + i + ", " + location.getDesc() + ".");
				i++;
			}
		} else {
			voice.speak("No Location exits");
		}

		voice.deallocate();
	}

	private static void showPermissionError() {
		System.out.println(
				"********************************************************************************************");
		System.out.println(
				"**************                                                         *********************");
		System.out.println(
				"**************   YOU DON'T HAVE PERMISSIONS TO PERFORM THIS FUNCTION   *********************");
		System.out.println(
				"**************                                                         *********************");
		System.out.println(
				"*********************************************************************************************");
	}

	// "Show all Staff" method from Database
	private static void showAllStaffOnDB() {

		try {

			// 1. Connect to DB
			Connection myConnection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/demo?serverTimezone=Australia/Sydney", "root", "52cY6^#q3%");

			// 2. Create statement
			Statement myStatement = myConnection.createStatement();

			// 3. Run SQL query
			ResultSet myResultSet = myStatement.executeQuery("select * from users");

			// 4. Process result set
			while (myResultSet.next()) {

				System.out.println(myResultSet.getInt("id") + ", " + myResultSet.getString("firstName") + ", "
						+ myResultSet.getString("lastName") + ", " + myResultSet.getInt("type") + ", "
						+ myResultSet.getString("userName") + ", " + myResultSet.getString("password1") + ", "
						+ myResultSet.getString("address") + ", " + myResultSet.getInt("postCode") + ", ");

			}

		} catch (Exception exception) {

			exception.printStackTrace();

		}

	}

}
